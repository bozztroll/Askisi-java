/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication14;

/**
 *
 * @author 
 */
import java.util.*;
public class JavaApplication14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //EXERCISE 1
        
       Random rand = new Random(); 
       List<Integer> intlist = new ArrayList<>();
       for (int i=0;i<10;i++){
          intlist.add(rand.nextInt(100)+1);
       }
         System.out.println(intlist);
         
         //EXERCISE 2
         
       List<Integer> intlist2 = new ArrayList<>();
       for (int i=0;i<10;i++){
          intlist2.add(rand.nextInt(100)+1);
       }
       List<Integer> intlist3 = new ArrayList<>();
       for (int i=0;i<10;i++){
          intlist3.add(intlist2.get(i));
       }
    
    System.out.println(intlist3);
    
    
     // EXERCISE 3
     /*
     List<Integer> intlist4 = new ArrayList<>();
    for (int i=0;i<100;i++){
        intlist4.add(rand.nextInt(50)+1);
    }
     */
    Scanner scn = new Scanner(System.in);
    /*
    System.out.println(intlist4);
    System.out.println("Give number ");
    int u=scn.nextInt();
    int c=0;
    for (int i=0;i<100;i++){
        if (intlist4.get(i).equals(u)){
          c+=1;  
        }
    }
    System.out.println("the number " + u + " has benn found " + c + " times");
    */
    // EXERCISE 4
    /*
    int max=0;
    List<Integer> intlist5 = new ArrayList();
    for (int i=0;i<50;i++){
      intlist5.add(rand.nextInt(100)+1);
      if (max <intlist5.get(i)){
          max=intlist5.get(i);
      }
    }
    
    System.out.println(intlist5);
    System.out.println(max);
*/
    
    // EXERCISE 5
    
    int max2=100;
    int min=10;
    
    List<Integer> intlist6 = new ArrayList();
    for (int i=0;i<50;i++){
        intlist6.add(rand.nextInt(max2-min)+min);
    }
    System.out.println(intlist6);
    Integer[] intArray = intlist6.toArray(new Integer[0]);
    //Collections.sort(intlist6);
   //System.out.println(intlist6);
   Arrays.sort(intArray);
  List<Integer> intlist7 = Arrays.asList(intArray);
  System.out.println(intlist7);
  
  // EXERCISE 8
  
    int a[][] = new int[3][3];
    int t=1;
    while (t!=0){
        System.out.println("type in what box do you want ");
           int b = scn.nextInt();
           int c = scn.nextInt();
     for (int i=0;i<3;i++){
       for (int j=0;j<3;j++){
            
        if (b-1==i){
            if (c-1==j){
             a[b-1][c-1] =1;  
             System.out.print(" __ __ __\n|_"+a[0][0]+"_|_"+a[0][1]+"_|_"+a[0][2]+"_|  ");
     System.out.print(" \n|_"+a[1][0]+"_|_"+a[1][1]+"_|_"+a[1][2]+"_|  ");
     System.out.print(" \n|_"+a[2][0]+"_|_"+a[2][1]+"_|_"+a[2][2]+"_|  ");
     System.out.println("type in what box do you want ");
            b = scn.nextInt();
            c = scn.nextInt();
            }
        }  
      t=0;
    
       }
     }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
        }
    }


